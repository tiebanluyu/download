---------------------------------------------------------------------------
PowerPoint to Flash: README
---------------------------------------------------------------------------

Please read this file carefully (especially "Installation"
chapter) before installing the program to your computer.

---------------------------------------------------------------------------
Contents
---------------------------------------------------------------------------

  Program information
  Company information
  Why using PowerPoint to Flash
  Description
  Installation and uninstallation
  History
  Registration
  Copyright and license
  Technical support

---------------------------------------------------------------------------
Program information
---------------------------------------------------------------------------

Program Name:
  PowerPoint to Flash
Program Version:
  2.6
Program Release Date:
  Apr 6, 2009
Program Description:
  Transfer PowerPoint presentations into Flash

System Requirement:
  Windows 98/Windows ME/Windows 2000/Windows XP
  Microsoft PowerPoint 2000/XP/2003/2007
Software Type:
  Shareware ($49.95)

---------------------------------------------------------------------------
Company information
---------------------------------------------------------------------------

Company Name:
  Dreamingsoft, Inc.
Contact E-mail Address:
  support@dreamingsoft.com
Contact WWW URL:
  http://www.dreamingsoft.com

---------------------------------------------------------------------------
Why using PowerPoint to Flash
---------------------------------------------------------------------------

You are losing opportunities, if your presentations can only be played back 
on the computer with Microsoft PowerPoint installed. Converting them into 
Flash now, and your presentations can be played back every where, Windows, 
Linux, Macintosh and even Hand held PCs, because Flash is the most popular 
format in the world now!

Instead of rebuilding all the presentations yourself, let your computer do 
it automatically with just a click on the Start button. Why not get more time 
to stay with your kids and enjoy your life?

Your skills on composing presentations with PowerPoint are not obsolete, just 
continue making your presentations with PowerPoint, and then covert them into 
Flash later.

---------------------------------------------------------------------------
Description
---------------------------------------------------------------------------

PowerPoint to Flash enables you to transfer bulk PowerPoint presentations 
into Flash, the world's most popular platform independent format.

---------------------------------------------------------------------------
Installation and uninstallation
---------------------------------------------------------------------------

Important! If you've got PowerPoint to Flash not from our web page, but 
from the other source (magazine CD or some software library), please visit
our home page - you'll probably find the later version;

Installation
Double click on the downloaded file pfsetup.exe, and then follow the on screen 
prompt.

Uninstallation
Open 'Add/Remove Programs' in Control Panel and double-click 'PowerPoint to 
Flash xx' in the list box.

---------------------------------------------------------------------------
History
---------------------------------------------------------------------------

See "history.txt" file.

---------------------------------------------------------------------------
Registration
---------------------------------------------------------------------------

See "order.txt" file.

---------------------------------------------------------------------------
Copyright and license
---------------------------------------------------------------------------

See "license.txt" file.

---------------------------------------------------------------------------
Technical support
---------------------------------------------------------------------------

In case you would like to download latest version of PowerPoint to Flash,
find out relative information, or register this program, please visit our 
website http://www.dreamingsoft.com

Our technical support staff will provide timely service on your problems
encountered during using our product. Please provide the following
information when you submit your questions:

  . The installed version of PowerPoint to Flash
  . The installed type and version of your operation system
  . The details of the problem you encounter. And if it is possible, please
    inform us how to reproduce this problem
  . Please provide your registration code in case you are a registered user
    and our technical support staff will deal with your problem with priority.

To get more helps from our technical support, you can contact us through
Email: support@dreamingsoft.com. At the meanwhile, it's our pleasure and
honor to receive any comments and suggestions from you.
